﻿using Microsoft.EntityFrameworkCore;
using ShoppingKart_project1.CartMicroservice.DataAccessLayer.Models;
using System.Collections.Generic;
using System.Reflection.Emit;

namespace ShoppingKart_project1.CartMicroservice.DataAccessLayer.Data
{
    public class CartContext : DbContext
    {
        public CartContext(DbContextOptions<CartContext> options) : base(options)
        {
        }
        public DbSet<CartItem> CartItems { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Configure the entity mappings and relationships
            modelBuilder.Entity<CartItem>().ToTable("CartItems");
            // Add any additional configurations as needed
        }
    }
}
