﻿using System.Collections.Generic;
using System.Linq;
using ShoppingKart_project1.CartMicroservice.DataAccessLayer.Data;
using ShoppingKart_project1.CartMicroservice.DataAccessLayer.Models;

namespace ShoppingKart_project1.CartMicroservice.DataAccessLayer.Repository
{
    public class CartRepository
    {
        private readonly CartContext _context;

        public CartRepository(CartContext context)
        {
            _context = context;
        }

        public IEnumerable<CartItem> GetCartItems()
        {
            return _context.CartItems.ToList();
        }

        public void AddCartItem(CartItem cartItem)
        {
            _context.CartItems.Add(cartItem);
            _context.SaveChanges();
        }

        public void RemoveCartItem(int cartItemId)
        {
            var cartItem = _context.CartItems.Find(cartItemId);
            if (cartItem != null)
            {
                _context.CartItems.Remove(cartItem);
                _context.SaveChanges();
            }
        }
    }
}
