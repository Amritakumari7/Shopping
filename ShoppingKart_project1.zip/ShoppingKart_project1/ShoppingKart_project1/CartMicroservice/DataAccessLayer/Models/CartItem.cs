﻿using System.ComponentModel.DataAnnotations;

namespace ShoppingKart_project1.CartMicroservice.DataAccessLayer.Models
{
    public class CartItem
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public int ProductId { get; set; }

        [Required]
        public string ProductName { get; set; }

        [Required]
        public decimal Price { get; set; }

        [Required]
        public int Quantity { get; set; }
    }
}