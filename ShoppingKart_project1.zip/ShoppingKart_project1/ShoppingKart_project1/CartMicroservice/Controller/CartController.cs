﻿using Microsoft.AspNetCore.Mvc;
using ShoppingKart_project1.CartMicroservice.BusinessLayer.ModelDto;
using ShoppingKart_project1.CartMicroservice.BusinessLayer.Services;

namespace ShoppingKart_project1.CartMicroservice.Controller
{
    [ApiController]
    [Route("api/[controller]")]
    public class CartController : ControllerBase
    {
        private readonly CartService _cartService;

        public CartController(CartService cartService)
        {
            _cartService = cartService;
        }

        [HttpGet]
        public IActionResult GetCartItems()
        {
            var cartItems = _cartService.GetCartItems();
            return Ok(cartItems);
        }

        [HttpPost]
        public IActionResult AddCartItem(CartItemDto cartItemDto)
        {
            _cartService.AddCartItem(cartItemDto);
            return Ok();
        }

        [HttpDelete("{id}")]
        public IActionResult RemoveCartItem(int id)
        {
            _cartService.RemoveCartItem(id);
            return Ok();
        }
    }
}
