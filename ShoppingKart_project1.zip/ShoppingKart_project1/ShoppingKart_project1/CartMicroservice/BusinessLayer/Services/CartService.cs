﻿using ShoppingKart_project1.CartMicroservice.BusinessLayer.ModelDto;
using ShoppingKart_project1.CartMicroservice.DataAccessLayer.Repository;
using ShoppingKart_project1.CartMicroservice.DataAccessLayer.Models;
using System.Collections.Generic;

namespace ShoppingKart_project1.CartMicroservice.BusinessLayer.Services
{
    public class CartService
    {
        private readonly CartRepository _cartRepository;

        public CartService(CartRepository cartRepository)
        {
            _cartRepository = cartRepository;
        }

        public IEnumerable<CartItemDto> GetCartItems()
        {
            // Retrieve the cart items from the repository
            var cartItems = _cartRepository.GetCartItems();

            // Map the cart items to DTOs and return the result
            var cartItemDtos = new List<CartItemDto>();
            foreach (var cartItem in cartItems)
            {
                var cartItemDto = MapCartItemToDto(cartItem);
                cartItemDtos.Add(cartItemDto);
            }

            return cartItemDtos;
        }

        public void AddCartItem(CartItemDto cartItemDto)
        {
            // Map the DTO to a cart item entity
            var cartItem = MapDtoToCartItem(cartItemDto);

            // Add the cart item to the repository
            _cartRepository.AddCartItem(cartItem);
        }

        public void RemoveCartItem(int cartItemId)
        {
            // Remove the cart item from the repository
            _cartRepository.RemoveCartItem(cartItemId);
        }

        // Helper method to map a cart item entity to a DTO
        private CartItemDto MapCartItemToDto(CartItem cartItem)
        {
            return new CartItemDto
            {
                Id = cartItem.Id,
                ProductId = cartItem.ProductId,
                ProductName = cartItem.ProductName,
                Price = cartItem.Price,
                Quantity = cartItem.Quantity
            };
        }

        // Helper method to map a DTO to a cart item entity
        private CartItem MapDtoToCartItem(CartItemDto cartItemDto)
        {
            return new CartItem
            {
                Id = cartItemDto.Id,
                ProductId = cartItemDto.ProductId,
                ProductName = cartItemDto.ProductName,
                Price = cartItemDto.Price,
                Quantity = cartItemDto.Quantity
            };
        }
    }
}
