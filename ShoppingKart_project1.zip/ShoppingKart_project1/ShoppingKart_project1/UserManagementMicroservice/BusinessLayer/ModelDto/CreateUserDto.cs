﻿namespace ShoppingKart_project1.UserManagementMicroservice.BusinessLayer.ModelDto
{
    public class CreateUserDto
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        // Add any other properties or fields as per your requirements
    }
}
