﻿namespace ShoppingKart_project1.UserManagementMicroservice.BusinessLayer.ModelDto
{
    public class UpdateUserDto
    {
        public int UserId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        // Add any other properties or fields as per your requirements
    }
}
