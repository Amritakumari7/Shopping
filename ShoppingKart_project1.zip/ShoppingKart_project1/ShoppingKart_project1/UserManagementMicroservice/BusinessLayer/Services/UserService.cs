﻿using ShoppingKart_project1.UserManagementMicroservice.BusinessLayer.ModelDto;
using ShoppingKart_project1.UserManagementMicroservice.DataAccessLayer.Models;
using ShoppingKart_project1.UserManagementMicroservice.DataAccessLayer.Repository;
using System.Collections.Generic;

namespace ShoppingKart_project1.UserManagementMicroservice.BusinessLayer.Services
{
    public class UserService
    {
        private readonly UserRepository _userRepository;

        public UserService(UserRepository userRepository)
        {
            _userRepository = userRepository;
        }

        public UserDto CreateUser(CreateUserDto userDto)
        {
            // Convert CreateUserDto to User entity
            var user = new User
            {
                // Map properties from CreateUserDto to User
                FirstName = userDto.FirstName,
                LastName = userDto.LastName,
                Email = userDto.Email
            };

            // Call the repository to create the user
            var createdUser = _userRepository.CreateUser(user);

            // Convert the created User entity back to UserDto
            var createdUserDto = new UserDto
            {
                // Map properties from createdUser to UserDto
                UserId = createdUser.UserId,
                FirstName = createdUser.FirstName,
                LastName = createdUser.LastName,
                Email = createdUser.Email
            };

            return createdUserDto;
        }

        public UserDto GetUserById(int userId)
        {
            var user = _userRepository.GetUserById(userId);

            if (user == null)
            {
                return null; // or throw an exception, depending on your requirement
            }

            var userDto = new UserDto
            {
                UserId = user.UserId,
                FirstName = user.FirstName,
                LastName = user.LastName,
                Email = user.Email
            };

            return userDto;
        }

        public List<UserDto> GetAllUsers()
        {
            var users = _userRepository.GetAllUsers();

            var userDtos = new List<UserDto>();

            foreach (var user in users)
            {
                var userDto = new UserDto
                {
                    UserId = user.UserId,
                    FirstName = user.FirstName,
                    LastName = user.LastName,
                    Email = user.Email
                };

                userDtos.Add(userDto);
            }
            return userDtos;
        }

        public UserDto UpdateUser(int userId, UpdateUserDto updateUserDto)
        {
            var userToUpdate = _userRepository.GetUserById(userId);

            if (userToUpdate == null)
            {
                return null; // or throw an exception, depending on your requirement
            }

            // Update the properties of the userToUpdate entity based on the updateUserDto
            userToUpdate.FirstName = updateUserDto.FirstName;
            userToUpdate.LastName = updateUserDto.LastName;
            userToUpdate.Email = updateUserDto.Email;

            // Call the repository to update the user
            var updatedUser = _userRepository.UpdateUser(userToUpdate);

            var updatedUserDto = new UserDto
            {
                UserId = updatedUser.UserId,
                FirstName = updatedUser.FirstName,
                LastName = updatedUser.LastName,
                Email = updatedUser.Email
            };

            return updatedUserDto;
        }

        public bool DeleteUser(int userId)
        {
            return _userRepository.DeleteUser(userId);
        }
    }
}
