﻿using Microsoft.AspNetCore.Mvc;
using ShoppingKart_project1.UserManagementMicroservice.BusinessLayer.ModelDto;
using ShoppingKart_project1.UserManagementMicroservice.BusinessLayer.Services;

namespace ShoppingKart_project1.UserManagementMicroservice.Controller
{
    [ApiController]
    [Route("api/[controller]")]
    public class UserController : ControllerBase
    {
        private readonly UserService _userService;

        public UserController(UserService userService)
        {
            _userService = userService;
        }

        [HttpGet]
        public IActionResult GetAllUsers()
        {
            var users = _userService.GetAllUsers();
            return Ok(users);
        }

        [HttpGet("{userId}")]
        public IActionResult GetUserById(int userId)
        {
            var user = _userService.GetUserById(userId);

            if (user == null)
            {
                return NotFound();
            }

            return Ok(user);
        }

        [HttpPost]
        public IActionResult CreateUser([FromBody] CreateUserDto userDto)
        {
            var createdUser = _userService.CreateUser(userDto);
            return CreatedAtAction(nameof(GetUserById), new { userId = createdUser.UserId }, createdUser);
        }

        [HttpPut("{userId}")]
        public IActionResult UpdateUser(int userId, [FromBody] UpdateUserDto updateUserDto)
        {
            var updatedUser = _userService.UpdateUser(userId, updateUserDto);

            if (updatedUser == null)
            {
                return NotFound();
            }

            return Ok(updatedUser);
        }

        [HttpDelete("{userId}")]
        public IActionResult DeleteUser(int userId)
        {
            var deleted = _userService.DeleteUser(userId);

            if (!deleted)
            {
                return NotFound();
            }

            return NoContent();
        }
    }
}
