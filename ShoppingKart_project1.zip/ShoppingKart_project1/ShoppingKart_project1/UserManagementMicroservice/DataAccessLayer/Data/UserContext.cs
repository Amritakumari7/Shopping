﻿using Microsoft.EntityFrameworkCore;
using ShoppingKart_project1.UserManagementMicroservice.DataAccessLayer.Models;

namespace ShoppingKart_project1.UserManagementMicroservice.DataAccessLayer.Data
{
    public class UserContext : DbContext
    {
        public DbSet<User> Users { get; set; }

        public UserContext(DbContextOptions<UserContext> options) : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Configure the entity mappings and relationships
            // ...

            base.OnModelCreating(modelBuilder);
        }
    }
}
