﻿using System.Collections.Generic;
using System.Linq;
using ShoppingKart_project1.UserManagementMicroservice.DataAccessLayer.Data;
using ShoppingKart_project1.UserManagementMicroservice.DataAccessLayer.Models;

namespace ShoppingKart_project1.UserManagementMicroservice.DataAccessLayer.Repository
{
    public class UserRepository
    {
        private readonly UserContext _context;

        public UserRepository(UserContext context)
        {
            _context = context;
        }

        public User CreateUser(User user)
        {
            _context.Users.Add(user);
            _context.SaveChanges();
            return user;
        }

        public User GetUserById(int userId)
        {
            return _context.Users.FirstOrDefault(u => u.UserId == userId);
        }

        public List<User> GetAllUsers()
        {
            return _context.Users.ToList();
        }

        public User UpdateUser(User user)
        {
            _context.Users.Update(user);
            _context.SaveChanges();
            return user;
        }

        public bool DeleteUser(int userId)
        {
            User userToDelete = _context.Users.FirstOrDefault(u => u.UserId == userId);

            if (userToDelete != null)
            {
                _context.Users.Remove(userToDelete);
                _context.SaveChanges();
                return true;
            }

            return false;
        }
    }
}
